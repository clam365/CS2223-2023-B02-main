package edu.wpi.cs2223.algorithms.week2;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * An implementation of the union find algorithm where the union operation is still quick, but has been
 * optimized to be intelligent in how it combines components - by re-parenting the smaller component
 * into the larger one instead of vice versa - this ensures that the size of components is as balanced as
 * possible.
 */
public class WeightedQuickUnionUF implements UnionFind {
    // a convenience array that enables to locate the linked node of interest based
    // on its integer value
    LinkedNode<Integer>[] nodes;
    AtomicInteger nextCounter;

    // TODO: implement maintainance of componentSize and componentCount
    int[] componentSize;

    int componentCount;

    @Override
    public void initialize(int size) {
        nextCounter = new AtomicInteger(0);

        nodes = ((LinkedNode<Integer>[]) new LinkedNode[size]);
        componentSize = new int[size];

        componentCount = size;

        for (int a = 0; a < size; a++){
            nodes[a] = new AccessTrackingNode<>(nextCounter, a, null);
            componentSize[a] = 1;
        }
    }

    @Override
    public boolean union(int p, int q) {
        // TODO: implement
        return false;
    }

    @Override
    public boolean connected(int p, int q) {
        // TODO: implement
        return false;
    }

    @Override
    public int find(int p) {
        // TODO: implement
        return 0;
    }

    @Override
    public int componentCount() {
        return componentCount;
    }

    public int countOfNextInvocations(){
        return nextCounter.get();
    }

    public int runningTime(int elementCount) {
        // TODO: implement
        return 0;
    }
}
