package edu.wpi.cs2223.algorithms.week2;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generic, Singly-linked list implementation of the SelectionSort algorithm.
 */
public class SelectionSort<T extends Comparable<T>> {
    /**
     * AtomicInteger in Java serves two purposes:
     * 1. primarily they are a thread-safe structure that permit, safe, concurrent access from multiple
     * Java threads.
     * 2. since Java passes arguments by value, Atomic structures give us a way for the updates (increments
     * in our case) from inside the method call to be reflected - since the value is not being updated, but the
     * state inside of it is.
     */
    AtomicInteger nextCounter;

    LinkedNode<T> head;

    LinkedNode<T> accessTrackingHead;

    public SelectionSort(LinkedNode<T> head) {
        this.head = head;

        InstrumentorResult<T> instrumentorResult = new LinkedNodeInstrumentor<T>().instrument(head);
        this.nextCounter = instrumentorResult.nextCounter;
        this.accessTrackingHead = instrumentorResult.head;
    }

    /**
     * Implementation of the time complexity of this algorithm.  Given the number of elements in the input
     * linked list, this method should return the (rough) expected number of invocations to the "next" operation
     * of the nodes in that list.
     *
     * @param elementCount number of nodes in input list
     * @return number of invocations to next across all nodes of that list necessary to get the list into its
     * sorted form.
     */
    public int runningTime(int elementCount) {
        // TODO: implement
        return 0;
    }

    /**
     * Applies Selection Sort to the list that this instance was initialized with.  The implementation should
     * perform the sort in place - that is, after the constructor of this implementation creates a chain of
     * AccessTrackingNode headed by accessTrackingHead, the implementation of this method should move nodes around
     * in this chain rather than creating new nodes or a new chain.
     *
     * @return reference to the node that is the head of the sorted chain.
     */
    public LinkedNode<T> sort(){
        // TODO: implement
        return accessTrackingHead;
    }

    /**
     * @return the number of times that next has been called across all linked nodes by this instance of the
     * selection sort algorithm.
     */
    public int countOfNextInvocations(){
        return nextCounter.get();
    }
}
