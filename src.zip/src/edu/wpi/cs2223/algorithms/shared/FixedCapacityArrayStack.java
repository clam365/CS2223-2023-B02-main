package edu.wpi.cs2223.algorithms.shared;

/**
 * Simple array backed stack implementation where the size of the array, and thus maximum size of
 * stack, is determined at construction time.
 *
 * @param <T> type of elements stored in stack.
 */
public class FixedCapacityArrayStack<T> implements Stack<T>{
    final int size;
    final T[] values;

    int head = -1;

    public FixedCapacityArrayStack(int size) {
        this.size = size;

        // Java does not support instantiation of a generically typed array, so we have to
        // create an array of Objects and cast it to our generic Array
        // the reasons for this limitation are involved but you are welcome to research them :)
        this.values = ((T[])new Object[size]);
    }

    @Override
    public void push(T value) {
        head++;
        values[head] = value;
    }

    @Override
    public T pop() {
        if (head == -1) {
            return null;
        }

        T returnValue = values[head];
        head--;
        return returnValue;
    }

    @Override
    public boolean isEmpty() {
        return head == -1;
    }
}
