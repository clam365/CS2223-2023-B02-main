package edu.wpi.cs2223.algorithms.shared;

/**
 * A simple generic queue backed by generic nodes.
 *
 * @param <T> type of value stored in the queue.
 */
public class LinkedListQueue<T> implements Queue<T>{

    Node<T> first = null;
    Node<T> last = null;

    public void enqueue(T value){
        if (first == null) {
            Node<T> newNode = new Node(null, value);
            first = newNode;
            last = newNode;
            return;
        }

        Node<T> newLast = new Node<>(null, value);
        last.next = newLast;
        last = newLast;
    }

    public T dequeue(){
        if (first == null) {
            return null;
        }
        T returnValue = first.value;
        first = first.next;

        return returnValue;
    }

    public boolean isEmpty(){
        return first == null;
    }
}
